import requests
import csv,time,json
import psycopg2
VAL_dict = {'Admin/HR':'01','CSI1':'02','CSI2':'03','CSI3':'04','CSI4':'05','CSI5':'06','ETD':'07','MemQual':'08','PA':'09','PKG':'10','PSU':'11','SE':'12'}
SDS_dict = {'Automation':'01','BIOS1':'02','BIOS2':'03','Diag':'04','FW1':'06','FW2':'07','FWQA':'08','iLOQA':'09','ROMQA':'11'}
EDS_dict = {'BOM':'01','CE':'02','EE Val':'03','EE/EE1':'04','EE/EE2':'05','EE/EE3':'06','LE/CPLD':'07','LE/ICQA':'08','PI':'09','SI':'10'}
PM_dict = {'ePM':'05','JV PMC':'10','SWPM':'12'}
#SRD_dict = {'ePM':'05','JV PMC':'10','SWPM':'12'}
GLB_dict = {'NPI':'01'}
ECAD_dict = {'layout':'01'}
EP_dict = {'PMC':'01'}
SDC_dict = {'Thermal-2':'01'}
CABG_dict = {'支援課':'01'}

#ROLE_dict = {'员工':'2','科长':'3','部长':'4','人资':'5'}

header = {'Content-Type': 'application/x-www-form-urlencoded',
'Accept': 'application/x-www-form-urlencoded',
'Accept-Encoding': 'gzip, deflate',
'Connection': 'keep-alive',
#'Cookie': 'connect.sid=s%3Ans1umVvq-TJVlSF1Q0s2_o1Jj9NqcAoM.QSRwUG5oM0OkF4gC758hoxkHJHBQo6MLgxKsw0JkuvQ',
'Upgrade-Insecure-Requests': '1',
'Referer:':'http://127.0.0.1:8088/src/assetlist.html',
'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'}
asset_list=[]

# def main():
    # dept_id = dept_id.strip()
    # team_id = team_id.strip()
    # sqlite_factory = connect_to(dept_id)

    # xml_factory = connect_to(team_id,dept_id)
    # parsed_data()




def connect_to(deptname,*teamname):
    factory = None
    try:
        if teamname != "" :
            factory = DeptConnector
        else:
            factory = TeamConnector
    except ValueError as ve:
        print(ve)
    return factory
    
class DeptConnector:
    def __init__(self, dept_id):
        text_header = 'ORG000000000000000000UUID'
        real_dept = text_header + dept_id.strip()


    def parsed_data(self):
        if len(real_dept) <= 29:
            num = 32 - len(real_dept)
            real_dept = real_dept + ('0' * num)
        elif len(real_dept) > 29 and 'Gloal' in real_dept:
            dept_id = "GLB"
            real_dept = text_header + dept_id.strip()+'0000'
        elif len(real_dept) > 29 and 'CABG' in real_dept:
            dept_id = "CABG"
            real_dept = text_header + dept_id.strip()+'000'
        return self.data


class TeamConnector:
    def __init__(self,dept_id,team_id):
        pass

    def parsed_data(self):
        if team_id != "" and dept_id.strip().upper() == 'PM':
            real_team = 'ORG000000000000000000UUIDSDS'+'00'+eval(dept_id.strip().upper()+"_dict")[team_id]
        elif team_id != "":
            team_num = 5-len(dept_id.strip())
            zero = '0' * team_num
            real_team = text_header + dept_id.strip()+zero+eval(dept_id.strip().upper()+"_dict")[team_id]


# def connector_factory(filepath):
    # if filepath == "datass.csv":
        # connector = AccountConnector
    # elif filepath == "assetdata.csv":
        # connector = AssetConnector
    # else:
        # raise ValueError('Cannot connect to {}'.format(filepath))
    # return connector(filepath)


def main(host, account, password):
    postUrl = "http://{0}/user/userLogin".format(host)
    postData = {
        "work_no": account,
        "password": password,
        "langueFlag": "zh-CN"
    }
    try:
        session = requests.Session()
        responseRes = session.post(postUrl, data = postData, headers = header)
        print(responseRes.status_code)
        for key, value in session.cookies.get_dict().items():
            COOKIE = key + "=" + value
            print('COOKIE:',COOKIE)

        header["Cookie"] = COOKIE
    except Error as error:
        print("session error!",error)
        return

    with open('assetdata.csv','r') as csvfile:
        try:
            reader = csv.reader(csvfile)
            rows= [row for row in reader]
        except Exception as e:
            print(e)
            return
                
    temp=0    
    for row in rows:
        if temp == 0:
            temp+=1
            continue
        dept_id = row[0]
        team_id = row[1]
        dev_type = row[2]
        asset_no = row[3]
        cumputer_name = row[4]
        cpu = row[5]
        memory = row[6]
        storage = row[7]
        mac = row[8]
        user_infoid = row[9]
        purpose = row[10]
        memo = row[11]
        
#******************88
# class normal_fac:
    # def dept_method(self, name):
        # num = 32 - len(name)
        # real_dept = name + ('0' * num)
# class unormal_fac:
    # def dept_method(self, name):
        # if len(name) > 29 and 'Gloal' in name:
            # dept_id = "GLB"
            # real_dept = text_header+name.strip()+'0000'
        # elif len(name) > 29 and 'CABG' in name:
            # dept_id = "CABG"
            # real_dept = text_header+name.strip()+'000'


        # text_header = 'ORG000000000000000000UUID'
        # def dep_id_factory(dept_id.strip()):
            # real_dept = text_header + dept_id.strip()
            # mode = normal_fac if len(real_dept) <= 29 else unormal_fac
            # environment = GameEnvironment(mode(dept_id.strip()))
            # environment.play()
            

#********************

        
        dept_id = dept_id.strip()
        team_id = team_id.strip()
        sqlite_factory = connect_to(dept_id)

        xml_factory = connect_to(team_id,dept_id)
        parsed_data()
        if dev_type == "笔记本电脑":
            real_type = 1
        elif dev_type== "台式机":
            real_type = 2
        elif dev_type == "硬盘":
            real_type = 3
        elif dev_type == "显示器":
            real_type = 4
        elif dev_type == "Server":
            real_type = 5
        elif dev_type == "伺服器":
            real_type = 6
        elif dev_type == "一体机":
            real_type = 7
        else:
            print("dev_type not in range {}！".format(dev_type))
            return
            
        data = {
            'dept_id': real_dept,
            'team_id': real_team,
            'dev_type' : real_type,
            'asset_no' : asset_no,
            'cumputer_name' : cumputer_name,
            'cpu' : cpu,
            'memory' : memory,
            'storage' : storage,
            'mac' : mac,
            'user_id' : 'USER00000000000000000000admin',
            'purpose' : 2,
            'memo' : memo,
            'status':1
        }
            
        response = requests.post("http://127.0.0.1:8088/asset/createAsset", data=data,headers=header)
        print(response.status_code)
        
        #zhuanzhang
        responses = response.json()
        print("**********************")
        tran_asset = responses['asset']['uuid']
        conn_db(tran_asset,user_infoid)


def conn_db(tran_asset,user_infoid):
    try:
        conn = psycopg2.connect(dbname="ams_db",user="postgres",password="111111",host="127.0.0.1")
        cur = conn.cursor()
        cur.execute('select u.work_no,u.uuid,u.name,u.dept_id,u.team_id from t_user u,t_org o,t_asset a where u.dept_id=o.uuid and u.work_no=' + "'"+user_infoid+"'" + 'group by u.work_no,u.uuid,u.name,u.dept_id,u.team_id')
        tran_info = cur.fetchall()
        tran_user1 = tran_info[0]
        tran_user = tran_info[0][1]
        tran_dept_id = tran_info[0][3]
        tran_team_id = tran_info[0][4]
    except Exception as e:
        print("DB conn fail!",e)
        return
    finally:
        print("Finally")
        conn.commit()
        cur.close()
        conn.close()
        
    tran_method(tran_asset,tran_user,tran_dept_id,tran_team_id)
    
def tran_method(tran_asset,tran_user,tran_dept_id,tran_team_id):
    tran_msg = {
                'man':0,
                'dept_id':tran_dept_id,
                'asset_id':tran_asset,
                'to_team_id':tran_team_id,
                'to_user_id':tran_user
                }
    tran_response = requests.post("http://127.0.0.1:8088/sign/assetTransfer", data=tran_msg,headers=header)
    print(tran_response.status_code)
    #print(tran_response.content)
    pass
    
    
if __name__ == "__main__":
    #main()
    host = "127.0.0.1:8088"
    main(host, "admin", "SRD123")
