import requests
import csv,time
#import http.cookiejar as cookielib

table_rule = {
    "VAL_dict": {'Admin/HR':'01','CSI1':'02','CSI2':'03','CSI3':'04','CSI4':'05','CSI5':'06','ETD':'07','MemQual':'08','PA':'09','PKG':'10','PSU':'11','SE':'12'},
    "SDS_dict":{'Automation':'01','BIOS1':'02','BIOS2':'03','Diag':'04','FW1':'06','FW2':'07','FWQA':'08','iLOQA':'09','ROMQA':'11'},
    "EDS_dict": {'BOM':'01','CE':'02','EE Val':'03','EE/EE1':'04','EE/EE2':'05','EE/EE3':'06','LE/CPLD':'07','LE/ICQA':'08','PI':'09','SI':'10'},
    "PM_dict": {'ePM':'05','JV PMC':'10','SWPM':'12'},
    #SRD_dict= {'ePM':'05','JV PMC':'10','SWPM':'12'}
    "GLB_dict": {'NPI':'01'},
    "ECAD_dict": {'layout':'01'},
    "EP_dict": {'PMC':'01'},
    "SDC_dict": {'Thermal-2':'01'},
    "CABG_dict": {'支援課':'01'},
    "ROLE_dict": {'员工':'2','科长':'3','部长':'4','人资':'5'}
}

def create_acc(host, account, password):
    print ("开始登录")
    header = {'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': 'application/x-www-form-urlencoded',
              'Accept-Encoding': 'gzip, deflate',
              'Connection': 'keep-alive',
              'Upgrade-Insecure-Requests': '1',
              'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
             }
    
    postUrl = "http://{0}/user/userLogin".format(host)
    postData = {
        "work_no": account,
        "password": password,
        "langueFlag": "zh-CN"
    }
    
    session = requests.Session()
    responseRes = session.post(postUrl, data = postData, headers = header)
    for key, value in session.cookies.get_dict().items():
        COOKIE = key + "=" + value

    header["Cookie"] = COOKIE
    with open('datass.csv','r') as csvfile:
        try:
            reader = csv.reader(csvfile)
            rows= [row for row in reader]
        except Exception as e:
            print(e)
        
    temp=0
    text_header = 'ORG000000000000000000UUID'
    for row in rows:
        if temp == 0:
            temp+=1
            continue
        name = row[0]
        work_no = row[1]
        dept_id = row[2]
        print("dept_id：",dept_id)
        team_id = row[3]
        print(team_id,"ddddddddd")
        user_type = row[4]
        tel = row[5]
        
        if dept_id.strip() != "":
            #real_dept = 'ORG000000000000000000UUID'+dept_id.strip()+'0000'
            real_dept = text_header + dept_id.strip()
            #global real_dept
            if len(real_dept) <= 29:
                num = 32 - len(real_dept)
                real_dept = real_dept + ('0' * num)
            elif len(real_dept) > 29 and 'Gloal' in real_dept:
                dept_id = "GLB"
                real_dept = text_header + dept_id.strip()+'0000'
            elif len(real_dept) > 29 and 'CABG' in real_dept:
                dept_id = "CABG"
                real_dept = text_header + dept_id.strip()+'000'
                
        print(team_id)
        if team_id != "" and dept_id.strip().upper() == 'PM':
            #real_team = 'ORG000000000000000000UUIDSDS'+'00'+eval(dept_id.strip().upper()+"_dict")[team_id]
            real_team = 'ORG000000000000000000UUIDSDS'+'00'+eval(str(table_rule[dept_id.strip().upper()+"_dict"]))[team_id]
        elif team_id != "":
            team_num = 5-len(dept_id.strip())
            zero = '0' * team_num
            #real_team = text_header + dept_id.strip()+zero+eval(dept_id.strip().upper()+"_dict")[team_id]
            real_team = text_header + dept_id.strip()+zero+eval(str(table_rule[dept_id.strip().upper()+"_dict"]))[team_id]

        real_role = table_rule['ROLE_dict'][user_type]
        print("real_team",real_team)
        data = {
            'user_type': real_role,
            'dept_id': real_dept,
            'team_id': real_team,
            'work_no': work_no,
            'name': str(name),
            'tel': tel
        }

        url = "http://{0}/user/createUser".format(host)
        #response = requests.post("http://127.0.0.1:8088/user/createUser", data = data,headers = header)
        response = session.post(url, data=data, headers=header)
        print(response.status_code)
if __name__ == "__main__":
   host = "127.0.0.1:8088"
   create_acc(host, "admin", "SRD123")

